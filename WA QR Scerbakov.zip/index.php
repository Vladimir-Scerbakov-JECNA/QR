<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR code generator</title>
</head>
<body>
    <form action="">
        <label for="url">URL:</label>
        <input type="text" name="url" placeholder="url">
        <br>
        <input type="submit" value="Generate">
    </form>
</body>
</html>
<?php

require_once 'phpqrcode/qrlib.php';

if(isset($_GET["url"])){
    $path = "qr.png";
    $url = $_GET["url"];
    QRcode::png($url,$path,'L',10);
    echo '<img src="'.$path.'">';
}


?>
